const FeedBackData=[
    {
        id:1,
        rating:5,
        text:"This is a list item 1"
    },
    {
        id:2,
        rating:8,
        text:"This is a list item 2"
    },
    {
        id:3,
        rating:9,
        text:"This is a list item 3"
    },
    {
        id:4,
        rating:6,
        text:"This is a list item 4"
    },
    
]
export default FeedBackData;