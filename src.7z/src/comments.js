import React from 'react'
const title="Here is my Blog Comments";


const commentList=[
    {id:1, text:"Comment One"},
    {id:2, text:"Comment Two"},
    {id:3, text:"Comment Three"},
  ];

function comments() {
    return (
        <div>
            <h1>My Blog</h1>
<p>{title}</p>
<h2>Comments: ({commentList.length})</h2>
{commentList.map((comment,index) =>(
<ul>
  <li key={index}>{comment.text}</li>
</ul>

))}
        </div>
    )
}

export default comments
