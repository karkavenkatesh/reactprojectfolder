import React from 'react';
import { useContext } from 'react';
import { FaTimes,FaEdit } from "react-icons/fa";
import Card from './shared/Card'
import FeedbackContext from '../context/FeedbackContext';

function FeedbackItem({item}) {
   
 const {deleteFeedbackItem,editFeedback} = useContext(FeedbackContext)

     return (
        <Card>       
          <div className="num-display"><span className="badge">{item.rating}</span></div>
        <button className="close" onClick={()=>deleteFeedbackItem(item.id)}>
          <FaTimes />
          </button>
          <button className="edit" onClick={()=>editFeedback(item)}>
          <FaEdit />
          </button>
          <div className="text-display">{item.text}</div>  
        
      </Card>
      
    )
}

export default FeedbackItem
