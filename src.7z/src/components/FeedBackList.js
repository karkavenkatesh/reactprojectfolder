import React from 'react'
import { useContext } from "react";
import FeedbackContext from '../context/FeedbackContext';
import FeedBackItem from './FeedbackItem'
function FeedBackList() {
    const {feedback} =  useContext(FeedbackContext)
    if(!feedback || feedback.length===0){
        return <p>No feedback yet !!!'</p>
    }
    return (
        <div className="feedback-list">
            {feedback.map((item)=>(
                <FeedBackItem key={item.id} item={item} />
            ))}
            
        </div>
    )
}

export default FeedBackList
