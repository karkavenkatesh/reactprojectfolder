import React from 'react'
import ProTypes from 'prop-types'

function Header({ text,reverse }) {

 
    return (
        <div className={`header ${reverse && 'reverse'}`}>
            <h1>{text}</h1>
        </div>
    )
}
Header.defaultProps={
text:"Header Section",
reverse:true,
}
Header.proTypes={
    text:ProTypes.string,
    reverse:ProTypes.bool,
    }
export default Header;
