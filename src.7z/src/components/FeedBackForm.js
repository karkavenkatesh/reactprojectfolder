import React from 'react'
import { useState,useContext,useEffect } from 'react'
import RatingSelected from './RatingSelected'
import Card from './shared/Card'
import Button from './shared/Button'
import FeedbackContext from '../context/FeedbackContext'

function FeedBackForm() {
    const{addFeedback,feedbackEdit,updateFeedback}=useContext(FeedbackContext)
    const [text, setText] = useState('');
    const [rating, setRating] = useState();
    const [btnDisabled, setBtnDisabled] = useState(true);
    const [message, setMessage] = useState('');
     useEffect(() => {
         if(feedbackEdit.edit===true){
            setBtnDisabled(false)
            setText(feedbackEdit.item.text)
            setRating(feedbackEdit.item.rating)

         }
   
    }, [feedbackEdit])
    const handleTextChange = (e) => {
        if (text === '') {
            setBtnDisabled(true)
            setMessage(null)
        }
        else if (text !== '' && text.trim().length <= 10) {
            setMessage('Atleast 10 char should be enter')
            setBtnDisabled(true)
        }
        else {
            setMessage(null)
            setBtnDisabled(false)
        }


        setText(e.target.value)

    }

    const handleSubmit = (e) => {
        e.preventDefault()
        if (text !== '' && text.trim().length > 10) {
            const newFeedback = {
                text,
                rating
            }
            if(feedbackEdit.edit===true){
                updateFeedback(feedbackEdit.item.id,newFeedback)
            }
            else{

                addFeedback(newFeedback)
            }
            setText('')
            setBtnDisabled(true)
        }
    }
    return (
        <Card>
            <form onSubmit={handleSubmit}>
                <h2>How would you rate your service with us?</h2>
                <RatingSelected select={(rating) => setRating(rating)} />
                <div className="input-group">
                    <input type='text' onChange={handleTextChange} placeholder='write a review' className='form-control' value={text} />
                    <Button type='submit' isDisabled={btnDisabled}>Send</Button>
                </div>
                <div className='message'>{message}</div>
            </form>
        </Card>
    )
}

export default FeedBackForm
