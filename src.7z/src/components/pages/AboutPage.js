import React from 'react'
import {Link,NavLink} from 'react-router-dom'
import Card from '../shared/Card'
function AboutPage() {
    return (
        <div>
<Card>
  <NavLink to='/' className=''>Home</NavLink>
  <NavLink to='/about' className='active'>About</NavLink>  
  </Card>

            AboutPage
            <Link to='/'>
                Back to home
            </Link>
        </div>
    )
}

export default AboutPage
