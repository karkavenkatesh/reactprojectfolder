import { createContext,useState } from "react";
import {v4 as uuidv4} from 'uuid'
import FeedBackData from "../FeedbackData"

const FeedbackContext=createContext()
export const FeedbackProvider=({children})=>{
    const [feedback,setFeedback]=useState(FeedBackData);
   const [feedbackEdit,setFeedbackEdit]=useState(
       {
           item:{},
           edit:false,
       }
   )
//    console.log(feedbackEdit.edit)
  const deleteFeedbackItem=(id)=>{
    if(window.confirm('Are you sure do you want to delete feedback')){
      setFeedback(feedback.filter((item)=>item.id !==id))

    }
    
  }
  const addFeedback=(newFeedback)=>{
    newFeedback.id=uuidv4()
    setFeedback([newFeedback,...feedback])
  }

  const editFeedback=(item)=>{
    setFeedbackEdit(
          {
          item,
          edit:true,
        }

      )
  }

  const updateFeedback=(id,updItem)=>{
    setFeedback(feedback.map((item)=>item.id===id ? {...item,...updItem} : item)) 
}
 
    return <FeedbackContext.Provider value=
    {{
       feedback,
       feedbackEdit,
       deleteFeedbackItem,
       addFeedback,
       editFeedback,
       updateFeedback,
    }}>
        {children}
    </FeedbackContext.Provider>
}
export default FeedbackContext